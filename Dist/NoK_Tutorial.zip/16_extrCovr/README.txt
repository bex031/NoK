전자해도 커버리지 추출

extrCovr을 실행해서 이 폴더에 있는 모든 000 파일의 M_COVR(CATCOV=1)인 객체를 추출하고 ALL_COVR.hob 파일로 저장

