Carisbatch를 이용해서 전자해도에서 Point 및 Sounding 타입인 피처들만 추출하기

아래 명령을 실행

carisbatch -r FilterFeatures -F "S-57 ENC 3.1" -U PS.crfx KR3F4G00.000 KR3F4G00.hob